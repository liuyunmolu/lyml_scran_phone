loading.js	是加载图片的js
getdata.php	是返回图片
count.data	这是 getdata.php生成的统计文件，里面只存放一个数字



关于统计的：
	1. 是要总的个数 还是要记录
	2. 是要文件保存，还是数据保存